
<?php get_template_part('templates/content-case', get_post_type()); ?>
