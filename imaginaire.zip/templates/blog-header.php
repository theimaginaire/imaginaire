<section class="blog-header">
<div class="container">
<h1 class="entry-title"><?php the_title(); ?></h1>
<?php get_template_part('templates/entry-meta'); ?>
</div>
</section>