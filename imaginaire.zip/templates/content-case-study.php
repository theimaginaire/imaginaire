<a href="<?php the_permalink(); ?>">
<div class="half-block animated fadeIn" style="animation-delay: 0.<?php echo $delay; ?>s;">

	<div class="bg" style="background-image: url(<?php the_field('tile_img'); ?>);">

	</div>

</div>
</a>