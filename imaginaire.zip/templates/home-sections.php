<?php get_template_part('templates/content', 'services'); ?>
<?php get_template_part('templates/snippet', 'testimonial'); ?>
<?php get_template_part('templates/content', 'sections'); ?>
<?php get_template_part('templates/snippet', 'blog'); ?>
<section class="strap cta">
	<div class="container">
	<p>are you looking to start a web design or digital marketing project?</p>
	<p><a href="<?php bloginfo('url'); ?>/project-planner/" class="btn btn-primary">try our project planner</a>
	</div>
</section>



		