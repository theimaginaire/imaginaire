<section class="services">
	<div class="container">
		<div class="row">
			<div class="col-md-12 center">
				<h2>Capabilities</h2>
			</div>
		</div>
		<?php get_template_part('templates/snippet', 'capabilities'); ?>
	</div>
</section>
<?php get_template_part('templates/content', 'sections'); ?>

<?php get_template_part('templates/snippet', 'testimonial'); ?>
<?php get_template_part('templates/content', 'bigcta'); ?>
