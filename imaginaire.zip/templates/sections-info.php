<?php get_template_part('templates/content', 'sections'); ?>

<?php get_template_part('templates/snippet', 'testimonial'); ?>
<?php get_template_part('templates/content', 'bigcta'); ?>
